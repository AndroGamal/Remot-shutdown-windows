﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        TcpClient clientSocket;
        TcpListener serverSocket;
        NetworkStream stream;
        Thread write,n;
        string s ,m;
        Boolean test;
        int start, end;
        Process process;
        private void read()
        {
            try
            {
               
                while (true)
                {
                    write = new Thread(r);
                    clientSocket = serverSocket.AcceptTcpClient();       
                    write.Start();
                }
            }
            catch (Exception e) {  }
            }
        private void r()
        {
            try
            {
                stream = clientSocket.GetStream();
                byte[] v = new byte[500000];
                stream.Read(v, 0, clientSocket.ReceiveBufferSize);
                s = System.Text.Encoding.ASCII.GetString(v);
                stream.Write(Encoding.UTF8.GetBytes("HTTP/1.0 200 \r\n"), 0, 15);
                stream.Write(Encoding.UTF8.GetBytes("Content type: text/html \r\n"), 0, 26);
                stream.Write(Encoding.UTF8.GetBytes("Content length: " + m.Length + "\r\n"), 0, m.Length.ToString().Length + 18);
                stream.Write(Encoding.UTF8.GetBytes("\r\n"), 0, 2);
                stream.Write(Encoding.UTF8.GetBytes(m + "\r\n"), 0, m.Length + 2);
                stream.Flush();
                stream.Close();
                clientSocket.Close();
                SetTextBox(textBox1, s);
                start=s.IndexOf("?f=") + 3;
                end= s.IndexOf(" HTTP/1.1");
                if (s.Substring(start, end - start) == "restart") {
                    process.StartInfo.Arguments = "/c shutdown /r /t 0";
                    process.Start(); 
      
                }
                else if (s.Substring(start, end - start) == "shutdown")
                {
                    process.StartInfo.Arguments = "/c shutdown /s /t 0";
                    process.Start(); ;
                }
            }
            catch (Exception e) { }
        }
        public void SetTextBox(TextBox textbox,String text)
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate() { SetTextBox(textbox, text); });
                return;
            }
            textbox.Text += text;
        }  
        string get_ip(){
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "null";
        }
        private void button1_Click(object sender, EventArgs e)
        {if(!test){
            button1.Text="Stop";
            textBox2.Text = "http://"+get_ip() + ":8080";
            Thread n=new Thread(read);
            serverSocket = new TcpListener(8080);
            serverSocket.Start();
            n.Start();
        }else{
        button1.Text="Start";
        serverSocket.Stop();
        write.Abort();
        }
            test=!test;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            m = "<!DOCTYPE html> \n" +
                   "<html>\n" +
                   "    <head>\n" +
                   "        <meta charset=\"UTF-8\">\n" +
                   "        <title>control</title>\n" +
                   "<style>\n" +
                   ".a\n" +
                   "{\n" +
                   " font-size: 20px;\n" +
                   "  background : green;\n" +
                   "    height: auto;\n" +
                   "   width: 100%;\n" +
                   "    border: 3px solid #73AD21;\n" +
                   "}\n" +
                   ".s\n" +
                   "{\n" +
                   "\n" +
                   " font-size: 20px;\n" +
                   "  background : rgb(128,140,140);\n" +
                   "    height: 100%;\n" +
                   "   width: 200px;\n" +
                   "    border: 3px solid rgb(128,110,110);\n" +
                   "}\n" +
                   ".h\n" +
                   "{  \n" +
                   "    width:196px;\n" +
                   "    background-color: #4CAF60;\n" +
                   "    border: none;\n" +
                   "    color: white;\n" +
                   "    padding: 16px 32px;\n" +
                   "    text-decoration: none;\n" +
                   "    margin: 4px 2px;\n" +
                   "    cursor: pointer;\n" +
                   "}\n" +
                   ".q\n" +
                   "{  \n" +
                   "    width:50%;\n" +
                   "    background-color: #4CAF60;\n" +
                   "    border: none;\n" +
                   "    color: white;\n" +
                   "    padding: 16px 32px;\n" +
                   "    text-decoration: none;\n" +
                   "    margin: 4px 2px;\n" +
                   "    cursor: pointer;\n" +
                   "}\n" +
                   ".q3\n" +
                   "{  \n" +
                   "    width:96%;\n" +
                   "    background-color: black;\n" +
                   "    border: 1;\n" +
                   "    color: white;\n" +
                   "    padding: 16px 32px;\n" +
                   "    text-decoration: none;\n" +
                   "    margin: 4px 2px;\n" +
                   "    cursor: pointer;\n" +
                   "}\n" +
                   ".tx\n" +
                   "{  \n" +
                   "    width:80%;\n" +
                   "    background-color: #4CAF60;\n" +
                   "    border: none;\n" +
                   "    color: white;\n" +
                   "    padding: 16px 32px;\n" +
                   "    text-decoration: none;\n" +
                   "    margin: 4px 2px;\n" +
                   "}\n" +
                   ".d\n" +
                   "{  \n" +
                   "    width:196px;\n" +
                   "    background-color: black;\n" +
                   "    border: none;\n" +
                   "    color: white;\n" +
                   "    padding: 16px 32px;\n" +
                   "    text-decoration: none;\n" +
                   "    margin: 4px 2px;\n" +
                   "    cursor: pointer;\n" +
                   "}\n" +
                   ".k div{\n" +
                   "float:left;\n" +
                   "}\n" +
                   ".ce{ width:100%;height: 90%;}" +
                   "</style>" +
                   "    </head>\n" +
                   "    <body>\n" +
                   "<form action=\"login.html\" method=\"post(a)\">\n" +
                   "        <div class=\"q3\" name=\"dev2\">\n" +
                   "<center>\n" +
                   "        <h1 name=\"q\">Control</h1>\n" +
                   "</center>\n" +
                   "        </div>\n" +
                   "        <div class=\"k\" name=\"a\">\n" +
                   "    <div class=\"ce\" name=\"div1\">\n" +
                   "        <br>\n" +
                   "        <br>\n" +
                   "        <br>\n" +
                   "         <center>\n" +
                   "              <table border=\"1\" name=\"a\" style=\"width:50%\" >\n" +
                   "  <tr>\n" +
                   "<td> \n" +
                   "<br>\n" +
                   "  <center><input class=\"a\" type=\"submit\" name=\"f\" value=\"restart\"  >\n" +
                    "  <tr>\n" +
                   "<td> \n" +
                   "  <center><input class=\"a\" type=\"submit\" name=\"f\" value=\"shutdown\"  >\n" +
                  "  <tr>\n" +
                   "<td> \n" +
                   "<br>\n" +
                   "</center>\n" +
                   "              </td>\n" +
                   "              </tr>     \n" +
                   "        </table> \n" +
                   "         </center>\n" +
                   "    </div>\n" +
                   "        </div>\n" +
                   "</form>" +
                   " </body>\n" +
                   "</html>\n";
            process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (test)
            {
                serverSocket.Stop();
                write.Abort();
            }
        }     
    
    }
}
