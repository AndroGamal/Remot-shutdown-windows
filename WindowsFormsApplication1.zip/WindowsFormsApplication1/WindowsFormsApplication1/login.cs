﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Threading;
using System.Diagnostics;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class login : Form
    {
        public login()
        {
            process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            fire = new FirebaseConfig()
            {
                AuthSecret = "8qgOVv8Ox790cjcYizHMJZT67c1nOsAzI35ZrCUh",
                BasePath = "https://shutdown-cc825.firebaseio.com/"
            };
            clint = new FireSharp.FirebaseClient(fire);
            try
            {
                using (StreamReader file = new StreamReader("user"))
                {
                    user = file.ReadLine();
                    pass = file.ReadLine();
                }
                    

            }
            catch (Exception e) { MessageBox.Show(e.Message); user = ""; }
            if (!user.Equals(""))
            {
                new Thread(read).Start();
                InitializeComponent();
                this.Opacity = 0;
                this.ShowInTaskbar = false;
            }
            else
            {
                InitializeComponent();
            }
        }
        string user,pass;
        IFirebaseConfig fire;
        IFirebaseClient clint;
        Process process;
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 o = new Form1();
            Visible = false;
            o.ShowDialog();
            Visible = true;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            using (StreamWriter filewriter = new StreamWriter("user"))
            {
                filewriter.WriteLine(name.Text.ToString());
                filewriter.WriteLine(password.Text.ToString());
            }
            var data = new Data{ 
             name=name.Text.ToString(),
             password=password.Text.ToString(),
             number=0
            };
            try
            {
                SetResponse o = await clint.SetAsync("users/" + name.Text + "/pc", data);
                MessageBox.Show("user = " + name.Text + "\npassword = " + password.Text);
                Visible = false;
                user = name.Text.ToString();
                new Thread(read).Start();
            }
            catch (FireSharp.Exceptions.FirebaseException ex)
            {
                MessageBox.Show("Not connect enternet\n work local");
            }
          
        }

       
     
        private async void read(){
            try {
                FirebaseResponse o;
                Data v;
                while (true)
                {
                    o = await clint.GetAsync("users/" + user + "/pc");
                    v = o.ResultAs<Data>();
                    if (v.number != 0)
                    {
                        if (v.number == 1)
                        {
                            process.StartInfo.Arguments = "/c shutdown /s /t 0";
                            reset();
                        }
                        else if (v.number == 2)
                        {
                            process.StartInfo.Arguments = "/c shutdown /r /t 0";
                            reset();
                           }
                    }
                }
            }
            catch (FireSharp.Exceptions.FirebaseException e)
            {
                Form1 o = new Form1();
                MessageBox.Show("Not connect enternet\n work local");
                o.ShowDialog();
                read();
            }
        }

        private async void reset()
        {
            var data = new Data
            {
                name = user,
                password = pass,
                number = 0
            };
            try
            {
                SetResponse o = await clint.SetAsync("users/" + user+ "/pc", data);
                process.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       }
}
