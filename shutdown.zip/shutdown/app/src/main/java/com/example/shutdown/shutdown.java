package com.example.shutdown;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class shutdown extends AppCompatActivity {
    Button restart, shutdown;
    DatabaseReference f;
    Query query;
    SharedPreferences.Editor write;
    SharedPreferences read;
    users o;

    @Override
    protected void onPause() {
        super.onPause();
        finish();
        moveTaskToBack(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shutdown);
        restart = findViewById(R.id.restart);
        shutdown = findViewById(R.id.shutdown);
        read = getSharedPreferences("users", MODE_MULTI_PROCESS);
        write = getSharedPreferences("users", MODE_MULTI_PROCESS).edit();
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set(2);
            }
        });
        shutdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set(1);
            }
        });
    }

    void set(final int x) {
        f = FirebaseDatabase.getInstance().getReference("users").child(read.getString("user", "@Null"));
        query = f.orderByChild("password").equalTo(read.getString("password", "@Null"));
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot g : dataSnapshot.getChildren()) {
                    o = g.getValue(users.class);
                    o.setNumber(x);
                    g.getRef().setValue(o);
                    Toast.makeText(shutdown.this, "Done", Toast.LENGTH_SHORT).show();
                    break;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}