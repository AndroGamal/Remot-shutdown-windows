package com.example.shutdown;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class local extends AppCompatActivity {
    Button shutdown, restart;
    WebView view;
    EditText text;

    @Override
    protected void onPause() {
        super.onPause();
        finish();
        moveTaskToBack(true);
  //      MainActivity.exit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local);
        getSupportActionBar().hide();
        shutdown = findViewById(R.id.shutdown);
        restart = findViewById(R.id.restart);
        view = new WebView(this);
        text = findViewById(R.id.editText);
        shutdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.loadUrl(text.getText() + "/login.html?f=shutdown");
            }
        });
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.loadUrl(text.getText() + "/login.html?f=restart");
            }
        });
    }
}
