package com.example.shutdown;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseReference f;
    SharedPreferences.Editor write;
    SharedPreferences read;
    EditText user, password;
    Button sign, localbutton;
    users o;
    Query query;
    ProgressBar progressBar;
    AlertDialog.Builder builder;
    AlertDialog cansel;

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return !(activeNetworkInfo != null && activeNetworkInfo.isConnected());
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
      start();
    }
public void start(){read = getSharedPreferences("users", MODE_MULTI_PROCESS);
    if (isNetworkAvailable()) {
        startActivity(new Intent(MainActivity.this, local.class));
    } else if (read.getString("user", "@Null") != "@Null") {
        startActivity(new Intent(MainActivity.this, shutdown.class));
    } else {
        setContentView(R.layout.activity_main);
        write = getSharedPreferences("users", MODE_MULTI_PROCESS).edit();
        user = findViewById(R.id.use);
        password = findViewById(R.id.pass);
        sign = findViewById(R.id.sign_in);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleInverse);
        builder = new AlertDialog.Builder(MainActivity.this).setMessage("wait...").setView(progressBar).setCancelable(false);
        cansel = builder.create();
        localbutton = findViewById(R.id.local);
        localbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, local.class));
            }
        });
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!user.getText().toString().matches("") && !password.getText().toString().matches("")) {
                    cansel.show();
                    f = FirebaseDatabase.getInstance().getReference("users").child(user.getText().toString());
                    query = f.orderByChild("password").equalTo(password.getText().toString());
                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            for (DataSnapshot g : dataSnapshot.getChildren()) {
                                o = g.getValue(users.class);
                                write.putString("user", o.getName());
                                write.putString("password", o.getPassword());
                                write.apply();
                                cansel.cancel();
                                startActivity(new Intent(MainActivity.this, shutdown.class));
                                break;
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }

                    });
                }
            }
        });
    }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    start();
    }

}

